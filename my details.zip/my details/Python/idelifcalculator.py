salary = int(input("Salary:"));
age = int(input("Age:"));

if(salary >= 20000 or age <= 25):
    print("loan amount eligibel");
else:
    print("loan amount not eligibel");
