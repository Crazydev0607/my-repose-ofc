compare = int(input("Enter input:"));

if(compare < 35):
    print("Poor Student");
elif(compare > 35 and compare < 70):
    print("Avarage Student");
elif(compare > 70 and compare < 100):
    print("Good Student");
else:
    print("Invalid Number");
