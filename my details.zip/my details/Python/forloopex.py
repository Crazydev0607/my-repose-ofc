a =[];
for i in range(5):
    num=int(input());
    a.append(num);
print(a)

     
