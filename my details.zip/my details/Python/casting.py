a = int(input());
b = int(input());
c = int(input());
Mul = a*b*c;
Add = a+b+c;
Divited = Mul/Add;

print(Divited);

