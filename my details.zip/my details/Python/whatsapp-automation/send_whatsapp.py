import os
import time
import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.chrome.options import Options

# Set Up Chrome Options
chrome_options = Options()
chrome_options.add_argument("--start-maximized")
chrome_options.add_argument("--disable-notifications")  # Prevent popups
chrome_options.add_argument("--log-level=3")  # Reduce logging noise

# Start WebDriver
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)

# Excel file path
excel_file = "contacts.xlsx"

# Load data from Excel
try:
    df = pd.read_excel(excel_file)
    df.columns = df.columns.str.strip()  # Remove spaces in column names
    if "Phone Number" not in df.columns or "Message" not in df.columns:
        raise KeyError("Excel file must contain 'Phone Number' and 'Message' columns.")
except Exception as e:
    print(f"❌ Error loading Excel file: {e}")
    driver.quit()
    exit()


def login_to_whatsapp():
    """ Opens WhatsApp Web and waits for QR code to be scanned """
    driver.get("https://web.whatsapp.com/")
    try:
        WebDriverWait(driver, 50).until(
            EC.presence_of_element_located((By.XPATH, "//h1[contains(text(), 'Chats')]"))
        )
        print("✅ WhatsApp Web loaded successfully!")
    except:
        input("❌ QR code not scanned! Please scan QR code and press Enter...")


# Call WhatsApp Login Function
login_to_whatsapp()

# Loop through contacts and send messages one by one
for index, row in df.iterrows():
    phone_number = str(row["Phone Number"]).strip()
    message = str(row["Message"]).strip()
    file_path = str(row["File"]).strip() if "File" in row and pd.notna(row["File"]) else None

    try:
        # Search for the contact
        search_box = WebDriverWait(driver, 20).until(
            EC.presence_of_element_located((By.XPATH, "//div[@contenteditable='true']"))
        )
        search_box.click()
        search_box.clear()
        search_box.send_keys(phone_number)
        time.sleep(4)  # Allow search to process properly

        # Open the chat
        try:
            first_chat = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, "//div[@role='gridcell']//span[@title]"))
            )
            first_chat.click()
        except Exception:
            print(f"⚠️ Contact {phone_number} not found. Skipping...")
            continue  # Move to the next contact

        print(f"📩 Opened chat for: {phone_number}")
        time.sleep(2)

        # Send message
        msg_box = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//div[@aria-label='Type a message']"))
        )
        msg_box.click()
        msg_box.send_keys(message)

        send_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//button[@aria-label='Send']"))
        )
        send_button.click()
        print(f"✅ Message sent to: {phone_number}")

        time.sleep(3)

        # ✅ If a valid file is provided, send it **only after message is sent**
        if file_path and os.path.exists(file_path):
            # Click on the "+" (attach) button
            attach_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, "//span[@data-icon='plus']"))
            )
            attach_button.click()
            time.sleep(1)

            # If file is a document (PDF, DOC, etc.)
            if file_path.lower().endswith((".pdf", ".doc", ".docx", ".txt")):
                doc_button = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.XPATH, "//span[text()='Document']"))
                )
                doc_button.click()
                file_input_xpath = "//input[@accept='*']"

            # If file is an image or video
            else:
                photo_video_button = WebDriverWait(driver, 10).until(
                    EC.element_to_be_clickable((By.XPATH, "//span[text()='Photos & videos']"))
                )
                photo_video_button.click()
                file_input_xpath = "//input[@accept='image/*,video/mp4,video/3gpp,video/quicktime']"

            # Wait for file input field to be visible and upload file
            upload_input = WebDriverWait(driver, 10).until(
                EC.presence_of_element_located((By.XPATH, file_input_xpath))
            )
            upload_input.send_keys(file_path)
            time.sleep(3)

            # Click send button for the file
            send_file_button = WebDriverWait(driver, 10).until(
                EC.element_to_be_clickable((By.XPATH, "//span[@data-icon='send']"))
            )
            send_file_button.click()

            # **WAIT UNTIL FILE IS SENT BEFORE MOVING TO THE NEXT USER**
            WebDriverWait(driver, 20).until(
                EC.presence_of_element_located((By.XPATH, "//span[contains(@data-icon, 'msg-check')]"))
            )
            print(f"📂 File sent to {phone_number}: {file_path}")

            time.sleep(2)  # Small pause to avoid issues

            # **NEW: Click cancel button after sending file (Fix file dialog issue)**
            # try:
            #     cancel_button = WebDriverWait(driver, 5).until(
            #         EC.element_to_be_clickable((By.XPATH, "//span[@data-icon='x']"))
            #     )
            #     cancel_button.click()
            #     print("✅ Closed file window after upload.")
            # except:
            #     print("⚠️ No cancel button found, continuing...")

            # time.sleep(2)

        else:
            print(f"⚠️ No valid file found for {phone_number}, skipping file upload.")

        time.sleep(5)  # Wait before moving to the next user

    except Exception as e:
        print(f"❌ Error sending to {phone_number}: {e}")

# Close the browser after processing all contacts
driver.quit()
