megna = input("megna died or not ?");
if(megna == "died"):
    print("okay");
else:
    print("No");
