import os
import time
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support import expected_conditions as EC

# Disable TensorFlow Logging (Not Needed for Your Script)
os.environ["TF_ENABLE_ONEDNN_OPTS"] = "0"
os.environ["TF_CPP_MIN_LOG_LEVEL"] = "3"

# Set Up Chrome Options
chrome_options = Options()
chrome_options.add_argument("--disable-webrtc")
chrome_options.add_argument("--disable-blink-features=WebRTC")
chrome_options.add_argument("--disable-features=WebRTC,WebRTC-HW-Decoding,WebRTC-HW-Encoding,WebRtcHideLocalIpsWithMdns")
chrome_options.add_argument("--start-maximized")
chrome_options.add_argument("--disable-webrtc-encryption")
chrome_options.add_argument("--disable-webrtc-hw-decoding")
chrome_options.add_argument("--disable-webrtc-hw-encoding")
chrome_options.add_argument("--disable-webrtc-ip-handling")

# Start WebDriver (Remove Duplicate WebDriver Instantiation)
driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=chrome_options)

# LinkedIn Credentials
LINKEDIN_EMAIL = "crazydev0607@gmail.com"
LINKEDIN_PASSWORD = "Siva@0"  # Update with your password
KEYWORD = "Angular Developer"
LOCATION = "Madurai"

# Personal Details for Job Application
RESUME_PATH = r"C:\Users\sivasankar\Documents\Python\My-Resume.pdf"
FIRST_NAME = "Siva"
LAST_NAME = "sankar"
PHONE_NO = "9344178558"
ADDRESS = "542, Solai alagu puram ramamoorthy nagar, Madurai-625011"
CURRENT_SALARY = "5,49,000"
EXPECTED_SALARY = "6,60,000"
EXPERIENCE_YEARS = "3"
LAST_WORKING_DAY = "31-03-2024"


def login_to_linkedin():
    driver.get("https://www.linkedin.com/login")
    time.sleep(3)

    email_field = driver.find_element(By.ID, "username")
    email_field.send_keys(LINKEDIN_EMAIL)

    password_field = driver.find_element(By.ID, "password")
    password_field.send_keys(LINKEDIN_PASSWORD)
    password_field.send_keys(Keys.RETURN)

    # Wait for security verification or home page
    try:
        WebDriverWait(driver, 60).until(
            EC.any_of(
                EC.presence_of_element_located((By.ID, "global-nav")),  # Home page
                EC.presence_of_element_located((By.ID, "verification-code-input"))  # Verification page
            )
        )

        # Check if verification is needed
        try:
            verification_input = driver.find_element(By.ID, "verification-code-input")
            print("Security verification needed. Please complete the verification.")
            # Wait for verification to complete
            WebDriverWait(driver, 300).until(EC.presence_of_element_located((By.ID, "global-nav"))) #Wait for 5 minutes
            print("Verification completed.")
        except:
            print("No verification needed.")

    except:
        print("Login failed or security verification timed out.")
        driver.quit()
        exit()

    time.sleep(3)

# ... (rest of the code)


def search_jobs():
    driver.get("https://www.linkedin.com/jobs/")

    wait = WebDriverWait(driver, 10)

    search_box = wait.until(EC.presence_of_element_located((By.XPATH, "//input[contains(@id, 'jobs-search-box-keyword-id')]")))
    search_box.send_keys(KEYWORD)
    time.sleep(2)

    location_box = wait.until(EC.presence_of_element_located((By.XPATH, "//input[contains(@id, 'jobs-search-box-location-id')]")))
    location_box.clear()
    location_box.send_keys(LOCATION)
    location_box.send_keys(Keys.RETURN)

    time.sleep(2)


def apply_to_jobs():
    while True:
        jobs = driver.find_elements(By.CLASS_NAME, "job-card-container")
        for job in jobs:
            try:
                driver.execute_script("arguments[0].scrollIntoView();", job)
                WebDriverWait(driver, 10).until(EC.element_to_be_clickable(job)).click()
                print("Clicked on job posting")

                # Check for Easy Apply using aria-label
                try:
                    WebDriverWait(driver, 5).until(EC.presence_of_element_located((By.XPATH, "//button[starts-with(@aria-label, 'Easy Apply to ') or contains(@aria-label,'Easy Apply')]")))
                    easy_apply_button = driver.find_element(By.XPATH, "//button[starts-with(@aria-label, 'Easy Apply to ') or contains(@aria-label,'Easy Apply')]")
                    easy_apply_button.click()
                    print("Easy Apply button clicked")

                    # Wait for the form to load
                    WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.XPATH, "//form")))

                    # Fill the form
                    try:
                        first_name_input = driver.find_element(By.ID, "single-line-text-form-component-formElement-urn-li-jobs-applyformcommon-easyApplyFormElement-4105625431-13896351284-text")
                        first_name_input.clear()
                        first_name_input.send_keys(FIRST_NAME)
                        print("First name added")
                    except:
                        print("First name not found")

                    try:
                        last_name_input = driver.find_element(By.ID, "single-line-text-form-component-formElement-urn-li-jobs-applyformcommon-easyApplyFormElement-4105625431-13896351268-text")
                        last_name_input.clear()
                        last_name_input.send_keys(LAST_NAME)
                        print("Last name added")
                    except:
                        print("Last name not found")

                    try:
                        country_code_select = Select(driver.find_element(By.ID, "text-entity-list-form-component-formElement-urn-li-jobs-applyformcommon-easyApplyFormElement-4105625431-13896351276-phoneNumber-country"))
                        country_code_select.select_by_visible_text("India (+91)")
                        print("Country code selected")
                    except:
                        print("Country code select not found")

                    try:
                        phone_number_input = driver.find_element(By.ID, "single-line-text-form-component-formElement-urn-li-jobs-applyformcommon-easyApplyFormElement-4105625431-13896351276-phoneNumber-nationalNumber")
                        phone_number_input.clear()
                        phone_number_input.send_keys(PHONE_NO)
                        print("Phone number added")
                    except:
                        print("Phone number not found")

                    try:
                        email_select = Select(driver.find_element(By.ID, "text-entity-list-form-component-formElement-urn-li-jobs-applyformcommon-easyApplyFormElement-4105625431-13896351252-multipleChoice"))
                        email_select.select_by_visible_text(LINKEDIN_EMAIL)
                        print("Email selected")
                    except:
                        print("Email select not found")

                    try:
                        location_input = driver.find_element(By.ID, "single-typeahead-entity-form-component-formElement-urn-li-jobs-applyformcommon-easyApplyFormElement-4105625431-13896351260-location-GEO-LOCATION")
                        location_input.clear()
                        location_input.send_keys(LOCATION)
                        print("Location added")
                    except:
                        print("location input not found")

                    # Click Next button
                    try:
                        next_button = driver.find_element(By.XPATH, "//button[@data-easy-apply-next-button]")
                        next_button.click()
                        print("Next button clicked")
                    except:
                        print("Next button not found")

                    # Wait for next form or submit button
                    # ... (Handle next form or submit button here) ...

                except Exception as e:
                    print(f"Not Easy Apply, skipping this job. Error: {e}")

            except Exception as e:
                print(f"Error: {e}")

        time.sleep(5)

# ... (rest of the code)


if __name__ == "__main__":
    login_to_linkedin()
    search_jobs()
    apply_to_jobs()
    driver.quit()