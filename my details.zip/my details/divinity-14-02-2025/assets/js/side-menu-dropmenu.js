$('.sub-menu ul').hide();
$(".sub-menu a").click(function () {
	$(this).parent(".sub-menu").children("ul").slideToggle("100").toggleClass("highlight-tab");
	$(this).parent(".sub-menu").children("a").toggleClass("highlight-tab-box");
	$(this).find(".right").toggleClass("fa-angle-up fa-angle-down");

});